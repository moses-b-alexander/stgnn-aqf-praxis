


class STANModelAdd(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        lpe=False,
        spe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.encoding_size = encoding_size
        self.spe = spe
        self.lpe = lpe

        # Linear projection for positional encoding
        self.feature_encoder = nn.Linear(input_size, encoding_size)

        # Positional Encodings
        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,
        )
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,
        )

        # Pre-GAT Attention
        self.pre_attention = MLPAttention(
            input_size=encoding_size,
            output_size=encoding_size,
            msg_size=hidden_size // (hidden_size // kernel_size),
            msg_layers=num_layers,
            norm="batch",
        )

        # Spatial Attention: GATConv
        self.gat = GATConv(
            in_channels=encoding_size,
            out_channels=hidden_size,
            heads=kernel_size,
            concat=True,
            dropout=dropout_rate,
        )

        # Temporal Attention
        self.temporal_attention = TemporalMLPAttention(
            input_size=hidden_size + covvariate_size,
            output_size=hidden_size,
            msg_size=hidden_size // (hidden_size // kernel_size),
            msg_layers=num_layers,
            norm="batch",
            dropout=dropout_rate,
        )

        # Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,
            hidden_size=hidden_size,
            output_size=horizon,
            receptive_field=4,
            activation="relu",
            dropout=dropout_rate,
        )

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Add positional encoding to raw input
        if self.spe:
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, -1, n_nodes, -1)

        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)
            pos_encoding = self.learnable_positional_encoding(positions)
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)

        x = self.feature_encoder(x)
        x += pos_encoding
        # Flatten input for Pre-GAT Attention
        x_flat = x.view(batch_size * time_steps, n_nodes, x.shape[-1])

        # Apply Pre-GAT Attention
        x_att = self.pre_attention(x_flat, edge_index)
        x_att = x_att.view(batch_size * time_steps, n_nodes, x_att.size(-1))

        # Apply GATConv
        gat_out = self.gat(x_att, edge_index)
        if isinstance(gat_out, tuple):
            gat_out = gat_out[0]
        gat_out = nn.functional.elu(gat_out)
        gat_out = gat_out.view(batch_size, time_steps, n_nodes, -1)

        # Prepare covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate GAT output and covariates
        temporal_input = torch.cat([gat_out, covariates], dim=-1)
        temporal_input = temporal_input.permute(0, 2, 1, 3).contiguous()

        # Apply Temporal Attention
        temporal_output = self.temporal_attention(temporal_input)
        temporal_output = temporal_output.permute(0, 2, 1, 3)

        # Decode Predictions
        predictions = self.decoder(temporal_output)
        predictions = predictions.permute(0, 2, 1, 3)
        predictions = predictions.permute(0, 3, 1, 2)

        return predictions



class STANModelConcat(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        lpe=False,
        spe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.encoding_size = encoding_size
        self.spe = spe
        self.lpe = lpe

        # Positional Encodings
        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,
        )
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,
        )

        # Pre-GAT Attention
        self.pre_attention = MLPAttention(
            input_size=input_size + encoding_size,
            output_size=input_size + encoding_size,
            msg_size=hidden_size // (hidden_size // kernel_size),
            msg_layers=num_layers,
            norm="batch",
        )

        # Spatial Attention: GATConv
        self.gat = GATConv(
            in_channels=input_size + encoding_size,
            out_channels=hidden_size,
            heads=kernel_size,
            concat=True,
            dropout=dropout_rate,
        )

        # Temporal Attention
        self.temporal_attention = TemporalMLPAttention(
            input_size=hidden_size + covvariate_size,
            output_size=hidden_size,
            msg_size=hidden_size // (hidden_size // kernel_size),
            msg_layers=num_layers,
            norm="batch",
            dropout=dropout_rate,
        )

        # Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,
            hidden_size=hidden_size,
            output_size=horizon,
            receptive_field=4,
            activation="relu",
            dropout=dropout_rate,
        )

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Concatenate positional encodings to raw input
        if self.spe:
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, -1, n_nodes, -1)

        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)
            pos_encoding = self.learnable_positional_encoding(positions)
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)

        x = torch.cat([x, pos_encoding], dim=-1)
        # Flatten input for Pre-GAT Attention
        x_flat = x.view(batch_size * time_steps, n_nodes, x.shape[-1])

        # Apply Pre-GAT Attention
        x_att = self.pre_attention(x_flat, edge_index)
        x_att = x_att.view(batch_size * time_steps, n_nodes, x_att.size(-1))

        # Apply GATConv
        gat_out = self.gat(x_att, edge_index)
        if isinstance(gat_out, tuple):
            gat_out = gat_out[0]
        gat_out = nn.functional.elu(gat_out)
        gat_out = gat_out.view(batch_size, time_steps, n_nodes, -1)

        # Prepare covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate GAT output and covariates
        temporal_input = torch.cat([gat_out, covariates], dim=-1)
        temporal_input = temporal_input.permute(0, 2, 1, 3).contiguous()

        # Apply Temporal Attention
        temporal_output = self.temporal_attention(temporal_input)
        temporal_output = temporal_output.permute(0, 2, 1, 3)

        # Decode Predictions
        predictions = self.decoder(temporal_output)
        predictions = predictions.permute(0, 2, 1, 3)
        predictions = predictions.permute(0, 3, 1, 2)

        return predictions




class DCRNNModelAdd(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        lpe=False,
        spe=False,
    ):
        super().__init__()

        self.hidden_size = hidden_size
        self.encoding_size = encoding_size
        self.spe = spe
        self.lpe = lpe

        # Projection to align positional encoding size with input_size
        self.feature_encoder = nn.Linear(input_size, encoding_size)

        # Sinusoidal Positional Encoding (SPE)
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,  # Use encoding_size for positional encodings
        )

        # Learnable Positional Encoding (LPE)
        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,  # Use encoding_size for learnable positional encodings
        )

        # Diffusion Convolution Layers (Spatial)
        self.diff_conv_1 = DiffConv(
            in_channels=encoding_size,
            out_channels=hidden_size,
            k=kernel_size,
            activation="relu"
        )
        self.diff_conv_2 = DiffConv(
            in_channels=hidden_size,
            out_channels=hidden_size,
            k=kernel_size,
            activation="relu"
        )

        # LSTM Layer (Temporal)
        self.lstm = nn.LSTM(
            input_size=hidden_size + covvariate_size,
            hidden_size=hidden_size,
            num_layers=num_layers
        )

        # Fully Connected Decoder
        self.fc = nn.Linear(hidden_size, horizon)

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None
    ):
        """
        Args:
            x: Node features [batch_size, time_steps, n_nodes, input_size]
            maximum_monthly_temperature: Covariates (e.g., max temperature) [batch_size, time_steps, n_nodes]
            minimum_monthly_temperature: Covariates (e.g., min temperature) [batch_size, time_steps, n_nodes]
            mean_monthly_temperature_extremity: Covariates [batch_size, time_steps, n_nodes]
            mean_monthly_temperature: Covariates [batch_size, time_steps, n_nodes]
            mean_annual_temperature: Covariates [batch_size, time_steps, n_nodes]
            edge_index: Adjacency list for the graph [2, num_edges]
        """
        batch_size, time_steps, n_nodes, input_size = x.shape

        if self.spe:
            # Apply Sinusoidal Positional Encoding (SPE)
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, encoding_size]
            # Project positional encoding to input_size
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        if self.lpe:
            # Apply Learnable Positional Encoding (LPE)
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_encoding = self.learnable_positional_encoding(positions)  # [1, time_steps, encoding_size]
            # Project positional encoding to input_size
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        # Flatten the input for graph convolution
        x = self.feature_encoder(x)
        x = x + pos_encoding
        x_flat = x.view(batch_size * time_steps, n_nodes, -1)  # [batch_size * time_steps, n_nodes, input_size]

        # Spatial convolution (Diffusion Convolution)
        spatial_out = self.diff_conv_1(x_flat, edge_index)
        spatial_out = torch.relu(spatial_out)

        spatial_out = self.diff_conv_2(spatial_out, edge_index)
        spatial_out = torch.relu(spatial_out)

        spatial_out = spatial_out.view(batch_size, time_steps, n_nodes, -1)  # [batch_size, time_steps, n_nodes, hidden_size]

        # Prepare covariates: Stack all covariates (maximum, minimum, mean temperatures, etc.)
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)  # [batch_size, time_steps, n_nodes, covariate_size]

        # Expand covariates to match the shape of spatial_out
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)  # [batch_size, time_steps, n_nodes, covariate_size]

        # Concatenate GNN output and covariates
        rnn_input = torch.cat([spatial_out, covariates], dim=-1)  # [batch_size, time_steps, n_nodes, hidden_size + covariate_size]
        rnn_input = rnn_input.permute(0, 2, 1, 3).reshape(batch_size * n_nodes, time_steps, -1)  # Flatten for GRU input

        # Temporal modeling with GRU
        rnn_out, _ = self.lstm(rnn_input)

        # We only take the last time step's output (seq_len, hidden_size) for each node
        rnn_out = rnn_out[:, -1, :].view(batch_size, n_nodes, -1)  # [batch_size, n_nodes, hidden_size]

        # Fully Connected Layer to produce the final predictions
        predictions = self.fc(rnn_out)  # [batch_size, n_nodes, horizon]

        # Permute the output to match desired shape: [batch_size, horizon, n_nodes, 1]
        predictions = predictions.permute(0, 2, 1).unsqueeze(-1)

        return predictions


class DCRNNModelConcat(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        lpe=False,
        spe=False,
    ):
        super().__init__()

        self.hidden_size = hidden_size
        self.encoding_size = encoding_size
        self.spe = spe
        self.lpe = lpe

        # Sinusoidal Positional Encoding (SPE)
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,  # Use encoding_size for positional encodings
        )

        # Learnable Positional Encoding (LPE)
        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,  # Use encoding_size for learnable positional encodings
        )

        # Diffusion Convolution Layers (Spatial)
        self.diff_conv_1 = DiffConv(
            in_channels=input_size + encoding_size,  # Concatenate positional encoding to input
            out_channels=hidden_size,
            k=kernel_size,
            activation="relu"
        )
        self.diff_conv_2 = DiffConv(
            in_channels=hidden_size,
            out_channels=hidden_size,
            k=kernel_size,
            activation="relu"
        )

        # LSTM Layer (Temporal)
        self.lstm = nn.LSTM(
            input_size=hidden_size + covvariate_size,  # Expecting the concatenated size
            hidden_size=hidden_size,
            num_layers=num_layers
        )

        # Fully Connected Decoder
        self.fc = nn.Linear(hidden_size, horizon)

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None
    ):
        """
        Args:
            x: Node features [batch_size, time_steps, n_nodes, input_size]
            maximum_monthly_temperature: Covariates (e.g., max temperature) [batch_size, time_steps, n_nodes]
            minimum_monthly_temperature: Covariates (e.g., min temperature) [batch_size, time_steps, n_nodes]
            mean_monthly_temperature_extremity: Covariates [batch_size, time_steps, n_nodes]
            mean_monthly_temperature: Covariates [batch_size, time_steps, n_nodes]
            mean_annual_temperature: Covariates [batch_size, time_steps, n_nodes]
            edge_index: Adjacency list for the graph [2, num_edges]
        """
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Apply Sinusoidal Positional Encoding (SPE)
        if self.spe:
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, encoding_size]
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        # Apply Learnable Positional Encoding (LPE)
        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_encoding = self.learnable_positional_encoding(positions)  # [1, time_steps, encoding_size]
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        # Flatten the input for graph convolution
        x = torch.cat([x, pos_encoding], dim=-1)  # Concatenate positional encoding Before convolution
        x_flat = x.view(batch_size * time_steps, n_nodes, -1)  # [batch_size * time_steps, n_nodes, input_size + encoding_size]

        # Spatial convolution (Diffusion Convolution)
        spatial_out = self.diff_conv_1(x_flat, edge_index)
        spatial_out = torch.relu(spatial_out)

        spatial_out = self.diff_conv_2(spatial_out, edge_index)
        spatial_out = torch.relu(spatial_out)

        spatial_out = spatial_out.view(batch_size, time_steps, n_nodes, -1)  # [batch_size, time_steps, n_nodes, hidden_size]

        # Prepare covariates: Stack all covariates (maximum, minimum, mean temperatures, etc.)
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)

        # Expand covariates to match the shape of spatial_out
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)  # [batch_size, time_steps, n_nodes, covariate_size]

        # Concatenate GNN output and covariates
        rnn_input = torch.cat([spatial_out, covariates], dim=-1)  # [batch_size, time_steps, n_nodes, hidden_size + covariate_size]
        rnn_input = rnn_input.permute(0, 2, 1, 3).reshape(batch_size * n_nodes, time_steps, -1)  # Flatten for GRU input

        # Temporal modeling with GRU
        rnn_out, _ = self.lstm(rnn_input)

        # We only take the last time step's output
        rnn_out = rnn_out[:, -1, :].view(batch_size, n_nodes, -1)  # [batch_size, n_nodes, hidden_size]

        # Fully Connected Layer to produce final predictions
        predictions = self.fc(rnn_out)  # [batch_size, n_nodes, horizon]

        # Permute the output to match desired shape: [batch_size, horizon, n_nodes, 1]
        predictions = predictions.permute(0, 2, 1).unsqueeze(-1)

        return predictions




class STTModelAdd(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        lpe=False,
        spe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.lpe = lpe
        self.spe = spe

        # Projection to align positional encoding size with input_size
        self.feature_encoder = nn.Linear(input_size, encoding_size)

        # Positional Encodings
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,
        )
        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,  # Maximum sequence length (time_steps)
            embedding_dim=encoding_size,  # Embedding size matches hidden size
        )

        # Spatial Attention: GATConv
        self.gat = GATConv(
            in_channels=encoding_size,
            out_channels=hidden_size,
            heads=kernel_size,
            concat=False,
            dropout=dropout_rate,
        )

        self.transformer_projection = nn.Linear(hidden_size + covariate_size, hidden_size)

        # Spatio-Temporal Transformer Encoder
        self.transformer_layers = nn.ModuleList([
            SpatioTemporalTransformerLayer(
                input_size=hidden_size,
                hidden_size=hidden_size,
                ff_size=hidden_size * 4,
                n_heads=kernel_size,
                activation="relu",
                dropout=dropout_rate,
            )
            for _ in range(num_layers)
        ])

        # Fully Connected Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,
            hidden_size=hidden_size,
            output_size=horizon,
            activation="relu",
            dropout=dropout_rate,
        )

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        batch_size, time_steps, n_nodes, input_size = x.shape

        x = self.feature_encoder(x)

        if self.spe:
            # Apply Sinusoidal Positional Encoding (SPE)
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, encoding_size]
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        if self.lpe:
            # Apply Learnable Positional Encoding (LPE)
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_encoding = self.learnable_positional_encoding(positions)  # [1, time_steps, encoding_size]
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        x += pos_encoding
        x_flat = x.view(batch_size * time_steps, n_nodes, -1)  # Flatten input for GAT
        spatial_out = self.gat(x_flat, edge_index)
        if isinstance(spatial_out, tuple):  spatial_out = spatial_out[0]
        spatial_out = nn.functional.elu(spatial_out)
        spatial_out = spatial_out.view(batch_size, time_steps, n_nodes, -1)

        # Prepare covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate GAT output and covariates
        spatiotemporal_input = torch.cat([spatial_out, covariates], dim=-1)
        spatiotemporal_input = self.transformer_projection(spatiotemporal_input)

        # Apply Spatio-Temporal Transformer Layers
        for layer in self.transformer_layers:
            spatiotemporal_input = layer(x=spatiotemporal_input)

        # Decode Predictions
        spatiotemporal_input = spatiotemporal_input.mean(dim=1)
        predictions = self.decoder(spatiotemporal_input)
        predictions = predictions.permute(0, 3, 2, 1)

        return predictions



class STTModelConcat(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        lpe=False,
        spe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.lpe = lpe
        self.spe = spe

        # Positional Encodings
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,
        )
        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,
        )

        # Spatial Attention: GATConv
        self.gat = GATConv(
            in_channels=input_size + encoding_size,
            out_channels=hidden_size,
            heads=kernel_size,
            concat=False,
            dropout=dropout_rate,
        )

        self.transformer_projection = nn.Linear(hidden_size + covariate_size, hidden_size)

        # Spatio-Temporal Transformer Encoder
        self.transformer_layers = nn.ModuleList([
            SpatioTemporalTransformerLayer(
                input_size=hidden_size,
                hidden_size=hidden_size,
                ff_size=hidden_size * 4,
                n_heads=kernel_size,
                activation="relu",
                dropout=dropout_rate,
            )
            for _ in range(num_layers)
        ])

        # Fully Connected Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,
            hidden_size=hidden_size,
            output_size=horizon,
            activation="relu",
            dropout=dropout_rate,
        )

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Apply Sinusoidal Positional Encoding (SPE)
        if self.spe:
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, encoding_size]
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        # Apply Learnable Positional Encoding (LPE)
        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_encoding = self.learnable_positional_encoding(positions)  # [1, time_steps, encoding_size]
            # Expand the positional encoding to match the input shape
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        x = torch.cat([x, pos_encoding], dim=-1)  # Concatenate positional encoding Before convolution
        x_flat = x.view(batch_size * time_steps, n_nodes, -1)
        spatial_out = self.gat(x_flat, edge_index)
        if isinstance(spatial_out, tuple):  spatial_out = spatial_out[0]
        spatial_out = nn.functional.elu(spatial_out)
        spatial_out = spatial_out.view(batch_size, time_steps, n_nodes, -1)

        # Prepare covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate GAT output and covariates
        spatiotemporal_input = torch.cat([spatial_out, covariates], dim=-1)
        spatiotemporal_input = self.transformer_projection(spatiotemporal_input)

        # Apply Spatio-Temporal Transformer Layers
        for layer in self.transformer_layers:
            spatiotemporal_input = layer(x=spatiotemporal_input)

        # Decode Predictions
        spatiotemporal_input = spatiotemporal_input.mean(dim=1)
        predictions = self.decoder(spatiotemporal_input)
        predictions = predictions.permute(0, 3, 2, 1)

        return predictions



class GPHModelAdd(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        spe=False,
        lpe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.encoding_size = encoding_size
        self.spe = spe
        self.lpe = lpe

        # Feature Encoder
        self.feature_encoder = nn.Linear(input_size, encoding_size)

        # Positional Encodings
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,  # Use encoding_size for positional encodings
        )

        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,  # Use encoding_size for learnable positional encodings
        )

        # Custom dimensions for Graphormer-specific encodings
        self.shortest_path_embedding = nn.Embedding(
            num_embeddings=max_path_distance + 1,
            embedding_dim=encoding_size,  # Use custom path_dim
        )
        self.centrality_embedding = nn.Embedding(
            num_embeddings=n_nodes + 1,
            embedding_dim=encoding_size,  # Use custom centrality_dim
        )

        transformer_dim = encoding_size + covariate_size
        self.nhead_projection = nn.Linear(transformer_dim, transformer_dim + kernel_size - (transformer_dim % kernel_size))
        transformer_dim_new = transformer_dim + kernel_size - (transformer_dim % kernel_size)
        self.transformer_projection = nn.Linear(transformer_dim_new, hidden_size)

        # Transformer Encoder Layer (using nn.TransformerEncoderLayer)
        self.transformer_layer = TransformerEncoderLayer(
            d_model=hidden_size,  # Concatenate hidden_size + path_dim + centrality_dim + encoding_size
            nhead=kernel_size,
            dim_feedforward=hidden_size * 4,
            dropout=dropout_rate,
            activation="relu",
        )
        self.transformer_encoder = TransformerEncoder(self.transformer_layer, num_layers=num_layers)

        # Fully Connected Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,  # Same as d_model
            hidden_size=hidden_size,
            output_size=horizon,
            activation="relu",
            dropout=dropout_rate,
        )

    def compute_shortest_path_encoding(self, edge_index, n_nodes, batch_size):
        """Compute shortest-path distances dynamically from edge_index."""
        adj = to_dense_adj(edge_index, max_num_nodes=n_nodes)  # [batch, n_nodes, n_nodes]
        dist = torch.where(adj == 0, max_path_distance + 1, adj)
        dist = torch.clamp(dist, max=max_path_distance)  # Limit distance to max_path_distance
        shortest_path_encoding = self.shortest_path_embedding(dist.long())  # [batch, n_nodes, n_nodes, path_dim]
        return shortest_path_encoding

    def compute_centrality_encoding(self, edge_index, n_nodes, batch_size):
        """Compute centrality encoding dynamically from edge_index."""
        centrality_scores = torch.bincount(edge_index[0], minlength=n_nodes)  # Degree centrality as proxy
        centrality_encoding = self.centrality_embedding(centrality_scores.long())  # [n_nodes, centrality_dim]
        centrality_encoding = centrality_encoding.unsqueeze(0).expand(batch_size, -1, -1)  # [batch, n_nodes, centrality_dim]
        return centrality_encoding

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        """
        Args:
            x: Node features [batch, time_steps, n_nodes, input_size]
            edge_index: Graph connectivity [2, num_edges]
            edge_weight: Edge weights [num_edges]
        """
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Feature Encoding
        x_encoded = self.feature_encoder(x)  # [batch, time_steps, n_nodes, hidden_size]

        # Apply Positional Encoding (Additive or Concatenative)
        if self.spe:
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, encoding_size]
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_encoding = self.learnable_positional_encoding(positions)  # [1, time_steps, encoding_size]
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        # Compute shortest-path encoding and centrality encoding
        shortest_path_encoding = self.compute_shortest_path_encoding(edge_index, n_nodes, batch_size)
        centrality_encoding = self.compute_centrality_encoding(edge_index, n_nodes, batch_size)

        # Flatten shortest path encoding and centrality encoding to be added to x_encoded
        shortest_path_encoding = shortest_path_encoding.mean(dim=2).unsqueeze(1).expand(-1, time_steps, -1, -1)  # [batch, time_steps, n_nodes, hidden_size]
        centrality_encoding = centrality_encoding.unsqueeze(1).expand(-1, time_steps, -1, -1)  # [batch, time_steps, n_nodes, hidden_size]

        # Add shortest path encoding and centrality encoding to node features
        x_encoded += pos_encoding
        x_encoded += shortest_path_encoding  # [batch, time_steps, n_nodes, hidden_size]
        x_encoded += centrality_encoding  # [batch, time_steps, n_nodes, hidden_size]

        # Prepare Covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate Covariates Before the Transformer
        x_encoded_with_covariates = torch.cat([x_encoded, covariates], dim=-1)  # [batch, time_steps, n_nodes, hidden_size + covariates]

        # Reshape for Transformer
        x_encoded_with_covariates = self.nhead_projection(x_encoded_with_covariates)
        transformer_input = x_encoded_with_covariates.permute(0, 2, 1, 3).reshape(batch_size * n_nodes, time_steps, -1)
        transformer_input = self.transformer_projection(transformer_input)

        # Apply Transformer Encoder
        transformer_output = self.transformer_encoder(transformer_input)  # [batch_size * n_nodes, time_steps, hidden_size + covariate_size]

        # Reshape back to [batch, time_steps, n_nodes, hidden_size + covariate_size]
        transformer_output = transformer_output.view(batch_size, n_nodes, time_steps, -1).permute(0, 2, 1, 3)

        # Decode Predictions
        transformer_output = transformer_output.mean(dim=1)  # Aggregate across time
        predictions = self.decoder(transformer_output)
        predictions = predictions.permute(0, 3, 2, 1)

        return predictions



class GPHModelConcat(BaseModel):
    def __init__(
        self,
        input_size,
        covariate_size,
        gnn_type,
        rnn_type,
        n_nodes,
        horizon,
        hidden_size,
        encoding_size,
        num_layers,
        kernel_size,
        dropout_rate,
        spe=False,
        lpe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.encoding_size = encoding_size
        self.spe = spe
        self.lpe = lpe

        # Positional Encodings
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=encoding_size,  # Use encoding_size for positional encodings
        )

        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=encoding_size,  # Use encoding_size for learnable positional encodings
        )

        # Custom dimensions for Graphormer-specific encodings
        self.shortest_path_embedding = nn.Embedding(
            num_embeddings=max_path_distance + 1,
            embedding_dim=encoding_size  # Use custom path_dim
        )
        self.centrality_embedding = nn.Embedding(
            num_embeddings=n_nodes + 1,
            embedding_dim=encoding_size,  # Use custom centrality_dim
        )

        transformer_dim = input_size + (encoding_size * 3) + covariate_size
        self.nhead_projection = nn.Linear(transformer_dim, transformer_dim + kernel_size - (transformer_dim % kernel_size))
        transformer_dim_new = transformer_dim + kernel_size - (transformer_dim % kernel_size)
        self.transformer_projection = nn.Linear(transformer_dim_new, hidden_size)

        # Transformer Encoder Layer (using nn.TransformerEncoderLayer)
        self.transformer_layer = TransformerEncoderLayer(
            d_model=hidden_size,  # Concatenate hidden_size + path_dim + centrality_dim + encoding_size
            nhead=kernel_size,
            dim_feedforward=hidden_size * 4,
            dropout=dropout_rate,
            activation="relu",
        )
        self.transformer_encoder = TransformerEncoder(self.transformer_layer, num_layers=num_layers)

        # Fully Connected Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,  # Same as d_model
            hidden_size=hidden_size,
            output_size=horizon,
            activation="relu",
            dropout=dropout_rate,
        )

    def compute_shortest_path_encoding(self, edge_index, n_nodes, batch_size):
        """Compute shortest-path distances dynamically from edge_index."""
        adj = to_dense_adj(edge_index, max_num_nodes=n_nodes)  # [batch, n_nodes, n_nodes]
        dist = torch.where(adj == 0, max_path_distance + 1, adj)
        dist = torch.clamp(dist, max=max_path_distance)  # Limit distance to max_path_distance
        shortest_path_encoding = self.shortest_path_embedding(dist.long())  # [batch, n_nodes, n_nodes, path_dim]
        return shortest_path_encoding

    def compute_centrality_encoding(self, edge_index, n_nodes, batch_size):
        """Compute centrality encoding dynamically from edge_index."""
        centrality_scores = torch.bincount(edge_index[0], minlength=n_nodes)  # Degree centrality as proxy
        centrality_encoding = self.centrality_embedding(centrality_scores.long())  # [n_nodes, centrality_dim]
        centrality_encoding = centrality_encoding.unsqueeze(0).expand(batch_size, -1, -1)  # [batch, n_nodes, centrality_dim]
        return centrality_encoding

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        """
        Args:
            x: Node features [batch, time_steps, n_nodes, input_size]
            edge_index: Graph connectivity [2, num_edges]
            edge_weight: Edge weights [num_edges]
        """
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Apply Positional Encoding (Additive or Concatenative)
        if self.spe:
            pos_encoding = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, encoding_size]
            pos_encoding = pos_encoding.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_encoding = self.learnable_positional_encoding(positions)  # [1, time_steps, encoding_size]
            pos_encoding = pos_encoding.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, input_size]

        # Compute shortest-path encoding and centrality encoding
        shortest_path_encoding = self.compute_shortest_path_encoding(edge_index, n_nodes, batch_size)
        centrality_encoding = self.compute_centrality_encoding(edge_index, n_nodes, batch_size)

        # Apply mean across the nodes dimension
        shortest_path_encoding = shortest_path_encoding.mean(dim=2)  # [batch, time_steps, n_nodes, path_dim]
        shortest_path_encoding = shortest_path_encoding.unsqueeze(1)  # [batch, 1, n_nodes, path_dim]
        shortest_path_encoding = shortest_path_encoding.expand(batch_size, time_steps, n_nodes, -1)  # [batch, time_steps, n_nodes, path_dim]

        centrality_encoding = centrality_encoding.unsqueeze(1).expand(-1, time_steps, -1, -1)  # [batch, time_steps, n_nodes, hidden_size]

        # Concatenate shortest path encoding and centrality encoding to node features
        x_encoded = torch.cat([x, pos_encoding, shortest_path_encoding, centrality_encoding], dim=-1)  # [batch, time_steps, n_nodes, hidden_size + path_dim + centrality_dim]

        # Prepare Covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate Covariates Before the Transformer
        x_encoded_with_covariates = torch.cat([x_encoded, covariates], dim=-1)  # [batch, time_steps, n_nodes, hidden_size + path_dim + centrality_dim + covariate_size]

        # Reshape for Transformer
        x_encoded_with_covariates = self.nhead_projection(x_encoded_with_covariates)
        transformer_input = x_encoded_with_covariates.permute(0, 2, 1, 3).reshape(batch_size * n_nodes, time_steps, -1)
        transformer_input = self.transformer_projection(transformer_input)

        # Apply Transformer Encoder
        transformer_output = self.transformer_encoder(transformer_input)  # [batch_size * n_nodes, time_steps, hidden_size + path_dim + centrality_dim + covariate_size]

        # Reshape back to [batch, time_steps, n_nodes, hidden_size + path_dim + centrality_dim + covariate_size]
        transformer_output = transformer_output.view(batch_size, n_nodes, time_steps, -1).permute(0, 2, 1, 3)

        # Decode Predictions
        transformer_output = transformer_output.mean(dim=1)  # Aggregate across time
        predictions = self.decoder(transformer_output)
        predictions = predictions.permute(0, 3, 2, 1)

        return predictions


class GPHModel(BaseModel):
    def __init__(
        self,
        input_size,
        n_nodes,
        horizon,
        hidden_size,
        num_layers,
        kernel_size,
        dropout_rate,
        spe=False,
        lpe=False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.spe = spe
        self.lpe = lpe
        self.max_dist = 19  # Max distance for shortest-path encoding

        # Positional Encodings
        self.sinusoidal_positional_encoding = sinusoidal_positional_encoding(
            max_len=window_length,
            hidden_size=hidden_size,
        )

        self.learnable_positional_encoding = nn.Embedding(
            num_embeddings=window_length,
            embedding_dim=hidden_size,
        )

        # Graphormer-specific encodings
        self.shortest_path_embedding = nn.Embedding(
            num_embeddings=max_dist + 1,  # Include "no-path" or max dist
            embedding_dim=hidden_size,
        )
        self.centrality_embedding = nn.Embedding(
            num_embeddings=n_nodes + 1,  # Centrality from 0 to n_nodes
            embedding_dim=hidden_size,
        )

        # Feature Encoder
        self.feature_encoder = nn.Linear(input_size, hidden_size)

        # Transformer Encoder
        self.transformer_layers = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=hidden_size,
                nhead=kernel_size,
                dim_feedforward=hidden_size * 4,
                dropout=dropout_rate,
                activation="relu",
            )
            for _ in range(num_layers)
        ])

        # Fully Connected Decoder
        self.decoder = MLPDecoder(
            input_size=hidden_size,
            hidden_size=hidden_size // 2,
            output_size=horizon,
            activation="relu",
            dropout=dropout_rate,
        )

    def compute_shortest_path_encoding(self, edge_index, n_nodes, batch_size):
        """Compute shortest-path distances dynamically from edge_index."""
        # Create dense adjacency matrix
        adj = to_dense_adj(edge_index, max_num_nodes=n_nodes)  # [batch, n_nodes, n_nodes]
        # Compute shortest-path distances using Floyd-Warshall or BFS (can use torch-geometric utilities)
        # For simplicity, we replace missing edges with max_dist + 1
        dist = torch.where(adj == 0, self.max_dist + 1, adj)
        dist = torch.clamp(dist, max=self.max_dist)  # Limit distance to max_dist
        # Embed shortest-path distances
        shortest_path_encoding = self.shortest_path_embedding(dist.long())  # [batch, n_nodes, n_nodes, hidden_size]
        return shortest_path_encoding

    def compute_centrality_encoding(self, edge_index, n_nodes, batch_size):
        """Compute centrality encoding dynamically from edge_index."""
        centrality_scores = torch.bincount(edge_index[0], minlength=n_nodes)  # Degree centrality as proxy
        centrality_encoding = self.centrality_embedding(centrality_scores.long())  # [n_nodes, hidden_size]
        centrality_encoding = centrality_encoding.unsqueeze(0).expand(batch_size, -1, -1)  # [batch, n_nodes, hidden_size]
        return centrality_encoding

    def forward(
        self,
        x,
        maximum_monthly_temperature,
        minimum_monthly_temperature,
        mean_monthly_temperature_extremity,
        mean_monthly_temperature,
        mean_annual_temperature,
        edge_index,
        edge_weight=None,
    ):
        """
        Args:
            x: Node features [batch, time_steps, n_nodes, input_size]
            edge_index: Graph connectivity [2, num_edges]
            edge_weight: Edge weights [num_edges]
        """
        batch_size, time_steps, n_nodes, input_size = x.shape

        # Feature Encoding
        x_encoded = self.feature_encoder(x)  # [batch, time_steps, n_nodes, hidden_size]

        # Apply Positional Encoding
        if self.spe:
            pos_enc = self.sinusoidal_positional_encoding[:time_steps, :].to(x.device)  # [time_steps, hidden_size]
            pos_enc = pos_enc.unsqueeze(0).unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)
            x_encoded += pos_enc

        if self.lpe:
            positions = torch.arange(0, time_steps, device=x.device).unsqueeze(0)  # [1, time_steps]
            pos_enc = self.learnable_positional_encoding(positions)  # [1, time_steps, hidden_size]
            pos_enc = pos_enc.unsqueeze(2).expand(batch_size, time_steps, n_nodes, -1)
            x_encoded += pos_enc

        # Compute shortest-path encoding and centrality encoding
        shortest_path_encoding = self.compute_shortest_path_encoding(edge_index, n_nodes, batch_size)
        centrality_encoding = self.compute_centrality_encoding(edge_index, n_nodes, batch_size)

        # Add centrality encoding to node features
        x_encoded += centrality_encoding.unsqueeze(1).expand(-1, time_steps, -1, -1)  # [batch, time_steps, n_nodes, hidden_size]

        # Reshape for Transformer
        transformer_input = x_encoded.permute(0, 2, 1, 3).reshape(batch_size * n_nodes, time_steps, -1)

        # Apply Transformer Layers
        for layer in self.transformer_layers:
            transformer_input = layer(transformer_input)

        # Reshape back to [batch, time_steps, n_nodes, hidden_size]
        transformer_output = transformer_input.view(batch_size, n_nodes, time_steps, -1).permute(0, 2, 1, 3)

        # Prepare Covariates
        covariates = torch.stack([
            maximum_monthly_temperature,
            minimum_monthly_temperature,
            mean_monthly_temperature_extremity,
            mean_monthly_temperature,
            mean_annual_temperature,
        ], dim=-1)
        covariates = covariates.unsqueeze(2).repeat(1, 1, n_nodes, 1)

        # Concatenate Transformer Output and Covariates
        spatiotemporal_input = torch.cat([transformer_output, covariates], dim=-1)

        # Decode Predictions
        spatiotemporal_input = spatiotemporal_input.mean(dim=1)  # Aggregate across time
        predictions = self.decoder(spatiotemporal_input)
        predictions = predictions.permute(0, 2, 1).unsqueeze(-1)

        return predictions




def optimize_dataset_hyperparams(trial):


    t0 = perf_counter()

    dataset = AirQuality(root="./data", small=beijing_subset)




    print(f"Sampling period: {dataset.freq}")
    print(f"Has missing values: {dataset.has_mask}")
    print(f"Percentage of missing values: {(1-dataset.mask.mean())*100:.2f}%")
    print(f"Has exogenous variables: {dataset.has_covariates}")
    print(f"Covariates: {', '.join(dataset.covariates.keys())}")

    print(DataFrame(dataset.dist))
    print(dataset.dist.shape)

    print(f"Default similarity: {dataset.similarity_score}")
    print(f"Available similarity options: {dataset.similarity_options}")
    print("==========================================")

    sim = dataset.get_similarity("distance")

    print(DataFrame(sim))
    print(sim.shape)

    print(dataset.dist.mean(axis=0).mean())
    print(dataset.dist.mean(axis=1).mean())

    ct = trial.suggest_float("connectivity_threshold", 0.2, 0.8, step=0.04)

    connectivity = dataset.get_connectivity(
        threshold=ct,
        include_self=False,
        normalize_axis=1,
        layout="edge_index"
        )

    edge_index, edge_weight = connectivity

    print(f"edge_index {edge_index.shape}:\n", edge_index)
    print(f"edge_weight {edge_weight.shape}:\n", edge_weight)


    torch_dataset = SpatioTemporalDataset(
        target=dataset.dataframe(),
        connectivity=connectivity,
        mask=dataset.mask,
        horizon=horizon_length,
        window=window_length,
        stride=1,
    )


    scalers = {"target": StandardScaler(axis=(0, 1))}

    splitter = TemporalSplitter(test_len=0.2, val_len=0.2)


    df = read_csv(os.path.join(os.getcwd(),
        "weather/monthly-climatology.csv"))
    annual = \
        read_csv(os.path.join(os.getcwd(), "weather/annual-average.csv"))
    annual_avg_temp_2014 = \
        annual.loc[annual.Category == 2014, "Annual Mean"].iloc[0]
    annual_avg_temp_2015 = \
        annual.loc[annual.Category == 2015, "Annual Mean"].iloc[0]


    mean_monthly_temperatures = []
    minimum_monthly_temperatures = []
    maximum_monthly_temperatures = []
    mean_monthly_precipitations = []
    for row in df.iterrows():
        if (row[0] + 1) in [9, 11, 1, 3, 4, 6, 8]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 31 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 31 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 31 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 31] * 31 * 24
        if (row[0] + 1) in [12, 2, 5, 7]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 30 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 30 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 30 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 30] * 30 * 24
        if (row[0] + 1) in [10]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 28 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 28 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 28 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 28] * 28 * 24

    if beijing_subset:
        mean_monthly_temperatures = mean_monthly_temperatures[:-1]
        minimum_monthly_temperatures = minimum_monthly_temperatures[:-1]
        maximum_monthly_temperatures = maximum_monthly_temperatures[:-1]
        mean_monthly_precipitations = mean_monthly_precipitations[:-1]

    torch_dataset.add_covariate(
        name="mean_annual_temperature",
        value=np.array(
            ([annual_avg_temp_2014] * 5880) +
            ([annual_avg_temp_2015] * (2880-1)) +
        []),
        pattern="t"
    )
    torch_dataset.add_covariate(
        name="mean_monthly_temperature",
        value=np.array(mean_monthly_temperatures),
        pattern="t"
    )

    torch_dataset.add_covariate(
        name="mean_monthly_temperature_extremity",
        value=np.array([np.abs(t - annual_avg_temp_2014)
            for t in mean_monthly_temperatures[:5880]] +
            [np.abs(t - annual_avg_temp_2015)
            for t in mean_monthly_temperatures[5880:]]),
        pattern="t"
    )

    torch_dataset.add_covariate(
        name="minimum_monthly_temperature",
        value=np.array(minimum_monthly_temperatures),
        pattern="t"
    )
    torch_dataset.add_covariate(
        name="maximum_monthly_temperature",
        value=np.array(maximum_monthly_temperatures),
        pattern="t"
    )



    print(dataset)
    print(torch_dataset)


    print(torch_dataset.covariates)


    # HYPERPARAMETERS

    input_size = torch_dataset.n_channels
    covariate_size = 5
    n_nodes = torch_dataset.n_nodes
    horizon = torch_dataset.horizon


    dm = SpatioTemporalDataModule(
        dataset=torch_dataset,
        splitter=TemporalSplitter(test_len=0.2, val_len=0.2),
        scalers=scalers,
        batch_size=batch_size,
        workers=num_workers-1,
        pin_memory=True,
    )


    stgnn = stgnn_class[0](
            input_size,
            covariate_size,
            stgnn_class[1],
            stgnn_class[2],
            n_nodes,
            horizon,
            hidden_units,
            encoding_dim,
            gnn_layers,
            rnn_layers,
            1,
            gnn_kernel,
            dropout,
            spe=stgnn_class[-2],
            lpe=stgnn_class[-1],
        )
    stgnn = stgnn.to(device)
    print(stgnn)

    tot = sum([p.numel() for p in stgnn.parameters() if p.requires_grad])
    out = f"Number of model ({stgnn.__class__.__name__}) parameters:{tot:10d}"
    print("=" * len(out), "\n", out)


    loss_fn = MaskedMAE(mask_nans=True)

    metrics = {
        "mae": MaskedMAE(),
        "mape": MaskedMAPE(),
        "mae_lag_01": MaskedMAE(at=1),
        "mae_lag_02": MaskedMAE(at=2),
        "mae_lag_03": MaskedMAE(at=3),
    }

    predictor = Predictor(
        model=stgnn,
        optim_class=torch.optim.Adam,
        optim_kwargs={"lr": learning_rate, "weight_decay": 0.0001},
        loss_fn=loss_fn,
        metrics=metrics,
    )


    logger = TensorBoardLogger(save_dir="logs", name="praxis", version=0)

    # %load_ext tensorboard
    # %tensorboard --logdir logs


    checkpoint_callback = ModelCheckpoint(
        dirpath="logs",
        save_top_k=1,
        monitor="val_mae",
        mode="min",
    )
    pl_callback = PatchedPLCallback(trial, "val_loss")

    trainer = pl.Trainer(
        max_epochs=num_epochs,
        logger=logger,
        precision="16-mixed",
        accelerator="gpu",
        devices=[0],
        limit_train_batches=1000,
        callbacks=[checkpoint_callback, pl_callback],
    )


    trainer.fit(predictor, datamodule=dm)



    predictor.load_model(checkpoint_callback.best_model_path)
    predictor.freeze()

    tt = trainer.test(predictor, datamodule=dm)


    t1 = perf_counter()
    print(f"\n\nRan for {round(t1-t0, 3)} seconds.\n\n")


    return tt[0]["test_mae"]



def optimize_training_hyperparams(trial):


    t0 = perf_counter()


    dataset = AirQuality(root="./data", small=beijing_subset)




    print(f"Sampling period: {dataset.freq}")
    print(f"Has missing values: {dataset.has_mask}")
    print(f"Percentage of missing values: {(1-dataset.mask.mean())*100:.2f}%")
    print(f"Has exogenous variables: {dataset.has_covariates}")
    print(f"Covariates: {', '.join(dataset.covariates.keys())}")

    print(DataFrame(dataset.dist))
    print(dataset.dist.shape)

    print(f"Default similarity: {dataset.similarity_score}")
    print(f"Available similarity options: {dataset.similarity_options}")
    print("==========================================")

    sim = dataset.get_similarity("distance")

    print(DataFrame(sim))
    print(sim.shape)

    print(dataset.dist.mean(axis=0).mean())
    print(dataset.dist.mean(axis=1).mean())

    connectivity = dataset.get_connectivity(
        threshold=connectivity_threshold,
        include_self=False,
        normalize_axis=1,
        layout="edge_index"
        )

    edge_index, edge_weight = connectivity

    print(f"edge_index {edge_index.shape}:\n", edge_index)
    print(f"edge_weight {edge_weight.shape}:\n", edge_weight)


    torch_dataset = SpatioTemporalDataset(
        target=dataset.dataframe(),
        connectivity=connectivity,
        mask=dataset.mask,
        horizon=horizon_length,
        window=window_length,
        stride=1,
    )


    scalers = {"target": StandardScaler(axis=(0, 1))}

    splitter = TemporalSplitter(test_len=0.2, val_len=0.2)







    df = read_csv(os.path.join(os.getcwd(),
        "weather/monthly-climatology.csv"))
    annual = \
        read_csv(os.path.join(os.getcwd(), "weather/annual-average.csv"))
    annual_avg_temp_2014 = \
        annual.loc[annual.Category == 2014, "Annual Mean"].iloc[0]
    annual_avg_temp_2015 = \
        annual.loc[annual.Category == 2015, "Annual Mean"].iloc[0]


    mean_monthly_temperatures = []
    minimum_monthly_temperatures = []
    maximum_monthly_temperatures = []
    mean_monthly_precipitations = []
    for row in df.iterrows():
        if (row[0] + 1) in [9, 11, 1, 3, 4, 6, 8]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 31 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 31 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 31 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 31] * 31 * 24
        if (row[0] + 1) in [12, 2, 5, 7]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 30 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 30 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 30 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 30] * 30 * 24
        if (row[0] + 1) in [10]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 28 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 28 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 28 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 28] * 28 * 24

    if beijing_subset:
        mean_monthly_temperatures = mean_monthly_temperatures[:-1]
        minimum_monthly_temperatures = minimum_monthly_temperatures[:-1]
        maximum_monthly_temperatures = maximum_monthly_temperatures[:-1]
        mean_monthly_precipitations = mean_monthly_precipitations[:-1]

    torch_dataset.add_covariate(
        name="mean_annual_temperature",
        value=np.array(
            ([annual_avg_temp_2014] * 5880) +
            ([annual_avg_temp_2015] * (2880-1)) +
        []),
        pattern="t"
    )
    torch_dataset.add_covariate(
        name="mean_monthly_temperature",
        value=np.array(mean_monthly_temperatures),
        pattern="t"
    )

    torch_dataset.add_covariate(
        name="mean_monthly_temperature_extremity",
        value=np.array([np.abs(t - annual_avg_temp_2014)
            for t in mean_monthly_temperatures[:5880]] +
            [np.abs(t - annual_avg_temp_2015)
            for t in mean_monthly_temperatures[5880:]]),
        pattern="t"
    )

    torch_dataset.add_covariate(
        name="minimum_monthly_temperature",
        value=np.array(minimum_monthly_temperatures),
        pattern="t"
    )
    torch_dataset.add_covariate(
        name="maximum_monthly_temperature",
        value=np.array(maximum_monthly_temperatures),
        pattern="t"
    )



    print(dataset)
    print(torch_dataset)


    print(torch_dataset.covariates)



    # HYPERPARAMETERS

    input_size = torch_dataset.n_channels
    covariate_size = 5
    n_nodes = torch_dataset.n_nodes
    horizon = torch_dataset.horizon


    lr = trial.suggest_float("learning_rate", 1e-4, 1e-1)
    bs = trial.suggest_int("batch_size", 16, 64, step=3)


    dm = SpatioTemporalDataModule(
        dataset=torch_dataset,
        scalers=scalers,
        splitter=TemporalSplitter(test_len=0.2, val_len=0.2),
        batch_size=bs,
        workers=num_workers-1,
        pin_memory=True,
    )


    stgnn = stgnn_class[0](
            input_size,
            covariate_size,
            stgnn_class[1],
            stgnn_class[2],
            n_nodes,
            horizon,
            hidden_units,
            encoding_dim,
            gnn_layers,
            rnn_layers,
            1,
            gnn_kernel,
            dropout,
            spe=stgnn_class[-2],
            lpe=stgnn_class[-1],
        )
    stgnn = stgnn.to(device)
    print(stgnn)

    tot = sum([p.numel() for p in stgnn.parameters() if p.requires_grad])
    out = f"Number of model ({stgnn.__class__.__name__}) parameters:{tot:10d}"
    print("=" * len(out), "\n", out)


    loss_fn = MaskedMAE()

    metrics = {
        "mae": MaskedMAE(),
        "mape": MaskedMAPE(),
        "mae_lag_01": MaskedMAE(at=1),
        "mae_lag_02": MaskedMAE(at=2),
        "mae_lag_03": MaskedMAE(at=3),
    }

    predictor = Predictor(
        model=stgnn,
        optim_class=torch.optim.Adam,
        optim_kwargs={"lr": lr, "weight_decay": 0.0001},
        loss_fn=loss_fn,
        metrics=metrics,
    )


    logger = TensorBoardLogger(save_dir="logs", name="praxis", version=0)

    # %load_ext tensorboard
    # %tensorboard --logdir logs


    checkpoint_callback = ModelCheckpoint(
        dirpath="logs",
        save_top_k=1,
        monitor="val_mae",
        mode="min",
    )
    pl_callback = PatchedPLCallback(trial, "val_loss")

    trainer = pl.Trainer(
        max_epochs=num_epochs,
        logger=logger,
        precision="16-mixed",
        accelerator="gpu",
        devices=[0],
        limit_train_batches=1000,
        callbacks=[checkpoint_callback, pl_callback],
    )

    trainer.fit(predictor, datamodule=dm)



    predictor.load_model(checkpoint_callback.best_model_path)
    predictor.freeze()

    tt = trainer.test(predictor, datamodule=dm)


    t1 = perf_counter()
    print(f"\n\nRan for {round(t1-t0, 3)} seconds.\n\n")


    return tt[0]["test_mae"]


def optimize_model_hyperparams(trial):


    t0 = perf_counter()


    dataset = AirQuality(root="./data", small=beijing_subset)




    print(f"Sampling period: {dataset.freq}")
    print(f"Has missing values: {dataset.has_mask}")
    print(f"Percentage of missing values: {(1-dataset.mask.mean())*100:.2f}%")
    print(f"Has exogenous variables: {dataset.has_covariates}")
    print(f"Covariates: {', '.join(dataset.covariates.keys())}")

    print(DataFrame(dataset.dist))
    print(dataset.dist.shape)

    print(f"Default similarity: {dataset.similarity_score}")
    print(f"Available similarity options: {dataset.similarity_options}")
    print("==========================================")

    sim = dataset.get_similarity("distance")

    print(DataFrame(sim))
    print(sim.shape)

    print(dataset.dist.mean(axis=0).mean())
    print(dataset.dist.mean(axis=1).mean())

    connectivity = dataset.get_connectivity(
        threshold=connectivity_threshold,
        include_self=False,
        normalize_axis=1,
        layout="edge_index"
        )

    edge_index, edge_weight = connectivity

    print(f"edge_index {edge_index.shape}:\n", edge_index)
    print(f"edge_weight {edge_weight.shape}:\n", edge_weight)


    torch_dataset = SpatioTemporalDataset(
        target=dataset.dataframe(),
        connectivity=connectivity,
        mask=dataset.mask,
        horizon=horizon_length,
        window=window_length,
        stride=1,
    )


    scalers = {"target": StandardScaler(axis=(0, 1))}

    splitter = TemporalSplitter(test_len=0.2, val_len=0.2)



    df = read_csv(os.path.join(os.getcwd(),
        "weather/monthly-climatology.csv"))
    annual = \
        read_csv(os.path.join(os.getcwd(), "weather/annual-average.csv"))
    annual_avg_temp_2014 = \
        annual.loc[annual.Category == 2014, "Annual Mean"].iloc[0]
    annual_avg_temp_2015 = \
        annual.loc[annual.Category == 2015, "Annual Mean"].iloc[0]


    mean_monthly_temperatures = []
    minimum_monthly_temperatures = []
    maximum_monthly_temperatures = []
    mean_monthly_precipitations = []
    for row in df.iterrows():
        if (row[0] + 1) in [9, 11, 1, 3, 4, 6, 8]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 31 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 31 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 31 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 31] * 31 * 24
        if (row[0] + 1) in [12, 2, 5, 7]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 30 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 30 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 30 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 30] * 30 * 24
        if (row[0] + 1) in [10]:
            mean_monthly_temperatures += \
                [row[1]["Average Mean Surface Air Temperature"]] * 28 * 24
            minimum_monthly_temperatures += \
                [row[1]["Average Minimum Surface Air Temperature"]] * 28 * 24
            maximum_monthly_temperatures += \
                [row[1]["Average Maximum Surface Air Temperature"]] * 28 * 24
            mean_monthly_precipitations += \
                [row[1]["Precipitation"] / 28] * 28 * 24

    if beijing_subset:
        mean_monthly_temperatures = mean_monthly_temperatures[:-1]
        minimum_monthly_temperatures = minimum_monthly_temperatures[:-1]
        maximum_monthly_temperatures = maximum_monthly_temperatures[:-1]
        mean_monthly_precipitations = mean_monthly_precipitations[:-1]

    torch_dataset.add_covariate(
        name="mean_annual_temperature",
        value=np.array(
            ([annual_avg_temp_2014] * 5880) +
            ([annual_avg_temp_2015] * (2880-1)) +
        []),
        pattern="t"
    )
    torch_dataset.add_covariate(
        name="mean_monthly_temperature",
        value=np.array(mean_monthly_temperatures),
        pattern="t"
    )

    torch_dataset.add_covariate(
        name="mean_monthly_temperature_extremity",
        value=np.array([np.abs(t - annual_avg_temp_2014)
            for t in mean_monthly_temperatures[:5880]] +
            [np.abs(t - annual_avg_temp_2015)
            for t in mean_monthly_temperatures[5880:]]),
        pattern="t"
    )

    torch_dataset.add_covariate(
        name="minimum_monthly_temperature",
        value=np.array(minimum_monthly_temperatures),
        pattern="t"
    )
    torch_dataset.add_covariate(
        name="maximum_monthly_temperature",
        value=np.array(maximum_monthly_temperatures),
        pattern="t"
    )



    print(dataset)
    print(torch_dataset)


    print(torch_dataset.covariates)



    # HYPERPARAMETERS

    input_size = torch_dataset.n_channels
    covariate_size = 5
    n_nodes = torch_dataset.n_nodes
    horizon = torch_dataset.horizon


    dm = SpatioTemporalDataModule(
        dataset=torch_dataset,
        scalers=scalers,
        splitter=TemporalSplitter(test_len=0.2, val_len=0.2),
        batch_size=batch_size,
        workers=num_workers-1,
        pin_memory=True,
    )

    hu = trial.suggest_int("hidden_units", 32, 512, step=32)
    ed = trial.suggest_int("encoding_dim", 16, 256, step=16)
    dr = trial.suggest_float("dropout_rate", 0.1, 0.85, step=0.05)

    stgnn = stgnn_class[0](
            input_size,
            covariate_size,
            stgnn_class[1],
            stgnn_class[2],
            n_nodes,
            horizon,
            hu,
            ed,
            gnn_layers,
            rnn_layers,
            1,
            gnn_kernel,
            dr,
            spe=stgnn_class[-2],
            lpe=stgnn_class[-1],
        )
    stgnn = stgnn.to(device)
    print(stgnn)

    tot = sum([p.numel() for p in stgnn.parameters() if p.requires_grad])
    out = f"Number of model ({stgnn.__class__.__name__}) parameters:{tot:10d}"
    print("=" * len(out), "\n", out)


    loss_fn = MaskedMAE()

    metrics = {
        "mae": MaskedMAE(),
        "mape": MaskedMAPE(),
        "mae_lag_01": MaskedMAE(at=1),
        "mae_lag_02": MaskedMAE(at=2),
        "mae_lag_03": MaskedMAE(at=3),
    }

    predictor = Predictor(
        model=stgnn,
        optim_class=torch.optim.Adam,
        optim_kwargs={"lr": learning_rate, "weight_decay": 0.0001},
        loss_fn=loss_fn,
        metrics=metrics,
    )


    logger = TensorBoardLogger(save_dir="logs", name="praxis", version=0)

    # %load_ext tensorboard
    # %tensorboard --logdir logs


    checkpoint_callback = ModelCheckpoint(
        dirpath="logs",
        save_top_k=1,
        monitor="val_mae",
        mode="min",
    )
    pl_callback = PatchedPLCallback(trial, "val_loss")

    trainer = pl.Trainer(
        max_epochs=num_epochs,
        logger=logger,
        precision="16-mixed",
        accelerator="gpu",
        devices=[0],
        limit_train_batches=1000,
        callbacks=[checkpoint_callback, pl_callback],
    )

    trainer.fit(predictor, datamodule=dm)



    predictor.load_model(checkpoint_callback.best_model_path)
    predictor.freeze()

    tt = trainer.test(predictor, datamodule=dm)


    t1 = perf_counter()
    print(f"\n\nRan for {round(t1-t0, 3)} seconds.\n\n")


    return tt[0]["test_mae"]


    # study_connectivity = optuna.create_study(direction="minimize")
    # study_connectivity.optimize(optimize_dataset_hyperparams, n_trials=num_trials)
    # print("Best trial for Connectivity Threshold:", study_connectivity.best_trial)

    # # study_lr_batch = optuna.create_study(direction="minimize")
    # # study_lr_batch.optimize(optimize_training_hyperparams, n_trials=num_trials)
    # # print("Best trial for Learning Rate and Batch Size:", study_lr_batch.best_trial)

    # study_model_params = optuna.create_study(direction="minimize")
    # study_model_params.optimize(optimize_model_hyperparams, n_trials=num_trials)
    # print("Best trial for Model Parameters:", study_model_params.best_trial)


